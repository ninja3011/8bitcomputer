
#include <stdio.h>
#include <stdlib.h>
typedef unsigned char BYTE;

int main(void)
{

FILE * fp1,* fp2,* fp3, * fp4;
fp1 = fopen("clog.txt", "w");


BYTE digits[]= {0x00,0x01, 0x02,0x03,0x04,0x05,0x06,0x07,0x08,0x09};

for(int i=0;i<=255;i++){
fprintf(fp1,"%x \n", digits[i%10]);
}
for(int i=0;i<=255;i++){
fprintf(fp2,"%x \n", digits[(i/10)%10]);
}
for(int i=0;i<=255;i++){
fprintf(fp3,"%x \n", digits[(i/100)%10]);
}
for(int i=0;i<=255;i++){
fprintf(fp4,"%x \n", (digits[(i/100)%10]<<16)|(digits[(i/10)%10] <<8) | digits[i%10] );
}

fclose(fp1);
fclose(fp2);
fclose(fp3);
fclose(fp4);
}
