
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
typedef unsigned char BYTE;

int main(void)
{
FILE * fp;
fp = fopen("control_logic.txt", "w");

uint16_t  HLT = 0b0000000000000001,
          MI  = 0b0000000000000010,
          RI  = 0b0000000000000100,
          RO  = 0b0000000000001000,
          IO  = 0b0000000000010000,
          II  = 0b0000000000100000,
          AI  = 0b0000000001000000,
          AO  = 0b0000000010000000,
          EO  = 0b0000000100000000,
          SU  = 0b0000001000000000,
          BI  = 0b0000010000000000,
          OI  = 0b0000100000000000,
          CE  = 0b0001000000000000,
          CO  = 0b0010000000000000,
          J   = 0b0100000000000000,
          FI  = 0b1000000000000000;

uint16_t data[] = {
MI|CO, RO |II | CE ,   0 ,     0 ,      0     , 0 , 0 , 0,     //NOP 00 0000
MI|CO, RO |II | CE , MI|IO , RO|AI ,    0     , 0 , 0 , 0,     //LDA 00 0001
MI|CO, RO |II | CE , MI|IO , RO|BI , AI|EO|FI , 0 , 0 , 0,     //ADD 00 0010
MI|CO, RO |II | CE , J |IO ,   0   ,    0     , 0 , 0 , 0,     //JMP 00 0011
MI|CO, RO |II | CE , IO|MI , AO|RI ,    0     , 0 , 0 , 0,     //STA 00 0100
MI|CO, RO |II | CE , AI|IO ,   0   ,    0     , 0 , 0 , 0,     //LDI 00 0101
MI|CO, RO |II | CE , MI|IO , RO|BI ,AI|EO|SU,0 , 0 , 0,     //SUB 00 0110
MI|CO, RO |II | CE ,   0 ,     0 ,      0     , 0 , 0 , 0,     //NOP 00 0111
MI|CO, RO |II | CE ,   0 ,     0 ,      0     , 0 , 0 , 0,     //NOP 00 1000
MI|CO, RO |II | CE ,   0 ,     0 ,      0     , 0 , 0 , 0,     //NOP 00 1001
MI|CO, RO |II | CE ,   0 ,     0 ,      0     , 0 , 0 , 0,     //NOP 00 1010
MI|CO, RO |II | CE ,   0 ,     0 ,      0     , 0 , 0 , 0,     //NOP 00 1011
MI|CO, RO |II | CE ,   0 ,     0 ,      0     , 0 , 0 , 0,     //NOP 00 1100
MI|CO, RO |II | CE ,   0 ,     0 ,      0     , 0 , 0 , 0,     //NOP 00 1101
MI|CO, RO |II | CE , AO|OI ,   0 ,      0     , 0 , 0 , 0,     //OUT 00 1110
MI|CO, RO |II | CE , HLT   ,   0 ,      0     , 0 , 0 , 0,     //HLT 00 1111

MI|CO, RO |II | CE ,   0 ,     0 ,      0     , 0 , 0 , 0,     //NOP 01 0000
MI|CO, RO |II | CE , MI|IO , RO|AI ,    0     , 0 , 0 , 0,     //LDA 01 0001
MI|CO, RO |II | CE , MI|IO , RO|BI , AI|EO|FI , 0 , 0 , 0,     //ADD 01 0010
MI|CO, RO |II | CE , J |IO ,   0   ,    0     , 0 , 0 , 0,     //J   01 0011
MI|CO, RO |II | CE , IO|MI , AO|RI ,    0     , 0 , 0 , 0,     //STA 01 0100
MI|CO, RO |II | CE , AI|IO ,   0   ,    0     , 0 , 0 , 0,     //LDI 01 0101
MI|CO, RO |II | CE , MI|IO , RO|BI ,AI|EO|SU,0 , 0 , 0,     //SUB 01 0110
MI|CO, RO |II | CE ,   0 ,     0 ,      0     , 0 , 0 , 0,     //NOP 01 0111
MI|CO, RO |II | CE ,   0 ,     0 ,      0     , 0 , 0 , 0,     //NOP 01 1000
MI|CO, RO |II | CE ,   0 ,     0 ,      0     , 0 , 0 , 0,     //NOP 01 1001
MI|CO, RO |II | CE , J |IO ,   0   ,    0     , 0 , 0 , 0,     //JC  01 1010
MI|CO, RO |II | CE ,   0 ,     0 ,      0     , 0 , 0 , 0,     //NOP 01 1011
MI|CO, RO |II | CE ,   0 ,     0 ,      0     , 0 , 0 , 0,     //NOP 01 1100
MI|CO, RO |II | CE ,   0 ,     0 ,      0     , 0 , 0 , 0,     //NOP 01 1101
MI|CO, RO |II | CE , AO|OI ,   0 ,      0     , 0 , 0 , 0,     //OUT 01 1110
MI|CO, RO |II | CE , HLT   ,   0 ,      0     , 0 , 0 , 0,     //HLT 01 1111

MI|CO, RO |II | CE ,   0 ,     0 ,      0     , 0 , 0 , 0,     //NOP 10 0000
MI|CO, RO |II | CE , MI|IO , RO|AI ,    0     , 0 , 0 , 0,     //LDA 10 0001
MI|CO, RO |II | CE , MI|IO , RO|BI , AI|EO|FI , 0 , 0 , 0,     //ADD 10 0010
MI|CO, RO |II | CE , J |IO ,   0   ,    0     , 0 , 0 , 0,     //J   10 0011
MI|CO, RO |II | CE , IO|MI , AO|RI ,    0     , 0 , 0 , 0,     //STA 10 0100
MI|CO, RO |II | CE , AI|IO ,   0   ,    0     , 0 , 0 , 0,     //LDI 10 0101
MI|CO, RO |II | CE , MI|IO , RO|BI ,AI|EO|SU,0 , 0 , 0,     //SUB 10 0110
MI|CO, RO |II | CE ,   0 ,     0 ,      0     , 0 , 0 , 0,     //NOP 10 0111
MI|CO, RO |II | CE ,   0 ,     0 ,      0     , 0 , 0 , 0,     //NOP 10 1000
MI|CO, RO |II | CE , J |IO ,   0   ,    0     , 0 , 0 , 0,     //JZ  10 1001
MI|CO, RO |II | CE ,   0 ,     0 ,      0     , 0 , 0 , 0,     //NOP 10 1010
MI|CO, RO |II | CE ,   0 ,     0 ,      0     , 0 , 0 , 0,     //NOP 10 1011
MI|CO, RO |II | CE ,   0 ,     0 ,      0     , 0 , 0 , 0,     //NOP 10 1100
MI|CO, RO |II | CE ,   0 ,     0 ,      0     , 0 , 0 , 0,     //NOP 10 1101
MI|CO, RO |II | CE , AO|OI ,   0 ,      0     , 0 , 0 , 0,     //OUT 10 1110
MI|CO, RO |II | CE , HLT   ,   0 ,      0     , 0 , 0 , 0,     //HLT 10 1111

MI|CO, RO |II | CE ,   0 ,     0 ,      0     , 0 , 0 , 0,     //NOP 11 0000
MI|CO, RO |II | CE , MI|IO , RO|AI ,    0     , 0 , 0 , 0,     //LDA 11 0001
MI|CO, RO |II | CE , MI|IO , RO|BI , AI|EO|FI , 0 , 0 , 0,     //ADD 11 0010
MI|CO, RO |II | CE , J |IO ,   0   ,    0     , 0 , 0 , 0,     //J   11 0011
MI|CO, RO |II | CE , IO|MI , AO|RI ,    0     , 0 , 0 , 0,     //STA 11 0100
MI|CO, RO |II | CE , AI|IO ,   0   ,    0     , 0 , 0 , 0,     //LDI 11 0101
MI|CO, RO |II | CE , MI|IO , RO|BI ,AI|EO|SU,0 , 0 , 0,     //SUB 11 0110
MI|CO, RO |II | CE ,   0 ,     0 ,      0     , 0 , 0 , 0,     //NOP 11 0111
MI|CO, RO |II | CE , J |IO ,   0   ,    0     , 0 , 0 , 0,     //JCZ 11 1000
MI|CO, RO |II | CE ,   0 ,     0 ,      0     , 0 , 0 , 0,     //NOP 11 1001
MI|CO, RO |II | CE ,   0 ,     0 ,      0     , 0 , 0 , 0,     //NOP 11 1010
MI|CO, RO |II | CE ,   0 ,     0 ,      0     , 0 , 0 , 0,     //NOP 11 1011
MI|CO, RO |II | CE ,   0 ,     0 ,      0     , 0 , 0 , 0,     //NOP 11 1100
MI|CO, RO |II | CE ,   0 ,     0 ,      0     , 0 , 0 , 0,     //NOP 11 1101
MI|CO, RO |II | CE , AO|OI ,   0 ,      0     , 0 , 0 , 0,     //OUT 11 1110
MI|CO, RO |II | CE , HLT   ,   0 ,      0     , 0 , 0 , 0,     //HLT 11 1111



};

for(int i = 0; i < 512; i++){
fprintf(fp,"%x \n",  data[i]);
}
fclose(fp);
}
